
import 'package:flutter/material.dart';

//class UIHelper {
TextStyle mTextStyle25({
  FontWeight mFontWeight = FontWeight.bold,
  Color mFontcolor = Colors.black}){
  return TextStyle(fontSize: 25,
      fontWeight: mFontWeight,
      color:mFontcolor
  );
}
TextStyle mTextStyle16({
  FontWeight mFontWeight = FontWeight.bold,
  Color mFontcolor = Colors.black}){
  return TextStyle(fontSize: 16,
      fontWeight: mFontWeight,
      color:mFontcolor
  );
}
TextStyle mTextStyle12({
  FontWeight mFontWeight = FontWeight.bold,
  Color mFontcolor = Colors.black}){
  return TextStyle(fontSize: 12,
      fontWeight: mFontWeight,
      color:mFontcolor
  );
}
TextStyle mTextStyle40({
  FontWeight mFontWeight = FontWeight.bold,
  Color mFontcolor = Colors.black}){
  return TextStyle(fontSize: 40,
      fontWeight: mFontWeight,
      color:mFontcolor
  );
}
/*
*/
