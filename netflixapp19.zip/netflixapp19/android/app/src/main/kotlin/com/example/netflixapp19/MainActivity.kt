package com.example.netflixapp19

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
